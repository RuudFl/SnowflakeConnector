//>>built
define("dijit/_Calendar",["dojo/_base/kernel","./Calendar","./main"],function(a,b,c){a.deprecated("dijit._Calendar is deprecated","dijit._Calendar moved to dijit.Calendar",2);c._Calendar=b});
