//>>built
define("dijit/form/nls/da/validate",{invalidMessage:"Den angivne v\u00e6rdi er ugyldig.",missingMessage:"V\u00e6rdien er p\u00e5kr\u00e6vet.",rangeMessage:"V\u00e6rdien er uden for intervallet."});
