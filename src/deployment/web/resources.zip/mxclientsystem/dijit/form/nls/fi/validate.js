//>>built
define("dijit/form/nls/fi/validate",{invalidMessage:"Annettu arvo ei kelpaa.",missingMessage:"T\u00e4m\u00e4 arvo on pakollinen.",rangeMessage:"T\u00e4m\u00e4 arvo on sallitun alueen ulkopuolella."});
