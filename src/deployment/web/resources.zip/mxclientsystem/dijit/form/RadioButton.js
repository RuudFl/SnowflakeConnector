//>>built
define("dijit/form/RadioButton",["dojo/_base/declare","./CheckBox","./_RadioButtonMixin"],function(a,b,c){return a("dijit.form.RadioButton",[b,c],{baseClass:"dijitRadio"})});
