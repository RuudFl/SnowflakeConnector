//>>built
define("dijit/form/nls/ro/Textarea",{iframeEditTitle:"zon\u0103 de editare",iframeFocusTitle:"cadru zon\u0103 de editare"});
