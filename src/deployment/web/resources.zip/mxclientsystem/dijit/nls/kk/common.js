//>>built
define("dijit/nls/kk/common",{buttonOk:"OK",buttonCancel:"\u0411\u043e\u043b\u0434\u044b\u0440\u043c\u0430\u0443",buttonSave:"\u0421\u0430\u049b\u0442\u0430\u0443",itemClose:"\u0416\u0430\u0431\u0443"});
