//>>built
define("dijit/form/nls/sv/validate",{invalidMessage:"Angivet v\u00e4rde \u00e4r inte giltigt.",missingMessage:"V\u00e4rdet kr\u00e4vs.",rangeMessage:"V\u00e4rdet ligger utanf\u00f6r intervallet."});
