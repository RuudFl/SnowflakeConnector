//>>built
define("dijit/form/ToggleButton",["dojo/_base/declare","dojo/_base/kernel","./Button","./_ToggleButtonMixin"],function(b,c,d,e){return b("dijit.form.ToggleButton",[d,e],{baseClass:"dijitToggleButton",setChecked:function(a){c.deprecated("setChecked("+a+") is deprecated. Use set('checked',"+a+") instead.","","2.0");this.set("checked",a)}})});
