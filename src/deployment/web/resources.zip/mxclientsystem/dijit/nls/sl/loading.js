//>>built
define("dijit/nls/sl/loading",{loadingState:"Nalaganje ...",errorState:"Oprostite, pri\u0161lo je do napake."});
